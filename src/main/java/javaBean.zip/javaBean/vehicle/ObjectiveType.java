
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ObjectiveType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ObjectiveType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ObjectiveRef" type="{}ObjectiveRefType"/>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ObjectivePeriod" type="{}ObjectivePeriodType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ObjectiveType", propOrder = {
    "objectiveRef",
    "name",
    "objectivePeriod"
})
public class ObjectiveType {

    @XmlElement(name = "ObjectiveRef", required = true)
    protected ObjectiveRefType objectiveRef;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "ObjectivePeriod", required = true)
    protected ObjectivePeriodType objectivePeriod;

    /**
     * 获取objectiveRef属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ObjectiveRefType }
     *     
     */
    public ObjectiveRefType getObjectiveRef() {
        return objectiveRef;
    }

    /**
     * 设置objectiveRef属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectiveRefType }
     *     
     */
    public void setObjectiveRef(ObjectiveRefType value) {
        this.objectiveRef = value;
    }

    /**
     * 获取name属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * 设置name属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * 获取objectivePeriod属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ObjectivePeriodType }
     *     
     */
    public ObjectivePeriodType getObjectivePeriod() {
        return objectivePeriod;
    }

    /**
     * 设置objectivePeriod属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectivePeriodType }
     *     
     */
    public void setObjectivePeriod(ObjectivePeriodType value) {
        this.objectivePeriod = value;
    }

}
