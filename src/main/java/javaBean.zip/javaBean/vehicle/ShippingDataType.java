
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ShippingDataType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ShippingDataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FullDestination" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransportType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ShipPort" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShippingDataType", propOrder = {
    "fullDestination",
    "transportType",
    "shipPort"
})
public class ShippingDataType {

    @XmlElement(name = "FullDestination", required = true)
    protected String fullDestination;
    @XmlElement(name = "TransportType", required = true)
    protected String transportType;
    @XmlElement(name = "ShipPort", required = true)
    protected String shipPort;

    /**
     * 获取fullDestination属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFullDestination() {
        return fullDestination;
    }

    /**
     * 设置fullDestination属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFullDestination(String value) {
        this.fullDestination = value;
    }

    /**
     * 获取transportType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransportType() {
        return transportType;
    }

    /**
     * 设置transportType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransportType(String value) {
        this.transportType = value;
    }

    /**
     * 获取shipPort属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipPort() {
        return shipPort;
    }

    /**
     * 设置shipPort属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipPort(String value) {
        this.shipPort = value;
    }

}
