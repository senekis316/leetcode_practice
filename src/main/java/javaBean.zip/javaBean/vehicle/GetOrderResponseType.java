
package javaBean.vehicle;

import javax.xml.bind.annotation.*;


/**
 * <p>GetOrderResponseType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="GetOrderResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PurchaseOrder" type="{}PurchaseOrderType"/>
 *         &lt;element name="VehicleSpecification" type="{}VehicleSpecificationType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement(name = "GetOrderResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetOrderResponseType", propOrder = {
    "purchaseOrder",
    "vehicleSpecification"
})
public class GetOrderResponseType {

    @XmlElement(name = "PurchaseOrder", required = true)
    protected PurchaseOrderType purchaseOrder;
    @XmlElement(name = "VehicleSpecification", required = true)
    protected VehicleSpecificationType vehicleSpecification;

    /**
     * 获取purchaseOrder属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PurchaseOrderType }
     *     
     */
    public PurchaseOrderType getPurchaseOrder() {
        return purchaseOrder;
    }

    /**
     * 设置purchaseOrder属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PurchaseOrderType }
     *     
     */
    public void setPurchaseOrder(PurchaseOrderType value) {
        this.purchaseOrder = value;
    }

    /**
     * 获取vehicleSpecification属性的值。
     * 
     * @return
     *     possible object is
     *     {@link VehicleSpecificationType }
     *     
     */
    public VehicleSpecificationType getVehicleSpecification() {
        return vehicleSpecification;
    }

    /**
     * 设置vehicleSpecification属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link VehicleSpecificationType }
     *     
     */
    public void setVehicleSpecification(VehicleSpecificationType value) {
        this.vehicleSpecification = value;
    }

}
