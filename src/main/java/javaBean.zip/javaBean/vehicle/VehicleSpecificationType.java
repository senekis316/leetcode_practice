
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>VehicleSpecificationType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="VehicleSpecificationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="VehicleSpecificationIdentifier" type="{}VehicleSpecificationIdentifierType"/>
 *         &lt;element name="ProductBrand" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ModelCoding" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ModelYear" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ModelVersion" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ColourInterior" type="{}ColourInteriorType"/>
 *         &lt;element name="Features" type="{}FeaturesType"/>
 *         &lt;element name="Prices" type="{}PricesType"/>
 *         &lt;element name="TechnicalData" type="{}TechnicalDataType"/>
 *         &lt;element name="ModelGroups" type="{}ModelGroupsType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VehicleSpecificationType", propOrder = {
    "vehicleSpecificationIdentifier",
    "productBrand",
    "modelCoding",
    "modelYear",
    "modelVersion",
    "colourInterior",
    "features",
    "prices",
    "technicalData",
    "modelGroups"
})
public class VehicleSpecificationType {

    @XmlElement(name = "VehicleSpecificationIdentifier", required = true)
    protected VehicleSpecificationIdentifierType vehicleSpecificationIdentifier;
    @XmlElement(name = "ProductBrand", required = true)
    protected String productBrand;
    @XmlElement(name = "ModelCoding", required = true)
    protected String modelCoding;
    @XmlElement(name = "ModelYear", required = true)
    protected String modelYear;
    @XmlElement(name = "ModelVersion", required = true)
    protected String modelVersion;
    @XmlElement(name = "ColourInterior", required = true)
    protected ColourInteriorType colourInterior;
    @XmlElement(name = "Features", required = true)
    protected FeaturesType features;
    @XmlElement(name = "Prices", required = true)
    protected PricesType prices;
    @XmlElement(name = "TechnicalData", required = true)
    protected TechnicalDataType technicalData;
    @XmlElement(name = "ModelGroups", required = true)
    protected ModelGroupsType modelGroups;

    /**
     * 获取vehicleSpecificationIdentifier属性的值。
     * 
     * @return
     *     possible object is
     *     {@link VehicleSpecificationIdentifierType }
     *     
     */
    public VehicleSpecificationIdentifierType getVehicleSpecificationIdentifier() {
        return vehicleSpecificationIdentifier;
    }

    /**
     * 设置vehicleSpecificationIdentifier属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link VehicleSpecificationIdentifierType }
     *     
     */
    public void setVehicleSpecificationIdentifier(VehicleSpecificationIdentifierType value) {
        this.vehicleSpecificationIdentifier = value;
    }

    /**
     * 获取productBrand属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductBrand() {
        return productBrand;
    }

    /**
     * 设置productBrand属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductBrand(String value) {
        this.productBrand = value;
    }

    /**
     * 获取modelCoding属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelCoding() {
        return modelCoding;
    }

    /**
     * 设置modelCoding属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelCoding(String value) {
        this.modelCoding = value;
    }

    /**
     * 获取modelYear属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * 设置modelYear属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelYear(String value) {
        this.modelYear = value;
    }

    /**
     * 获取modelVersion属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelVersion() {
        return modelVersion;
    }

    /**
     * 设置modelVersion属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelVersion(String value) {
        this.modelVersion = value;
    }

    /**
     * 获取colourInterior属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ColourInteriorType }
     *     
     */
    public ColourInteriorType getColourInterior() {
        return colourInterior;
    }

    /**
     * 设置colourInterior属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ColourInteriorType }
     *     
     */
    public void setColourInterior(ColourInteriorType value) {
        this.colourInterior = value;
    }

    /**
     * 获取features属性的值。
     * 
     * @return
     *     possible object is
     *     {@link FeaturesType }
     *     
     */
    public FeaturesType getFeatures() {
        return features;
    }

    /**
     * 设置features属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link FeaturesType }
     *     
     */
    public void setFeatures(FeaturesType value) {
        this.features = value;
    }

    /**
     * 获取prices属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PricesType }
     *     
     */
    public PricesType getPrices() {
        return prices;
    }

    /**
     * 设置prices属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PricesType }
     *     
     */
    public void setPrices(PricesType value) {
        this.prices = value;
    }

    /**
     * 获取technicalData属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TechnicalDataType }
     *     
     */
    public TechnicalDataType getTechnicalData() {
        return technicalData;
    }

    /**
     * 设置technicalData属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TechnicalDataType }
     *     
     */
    public void setTechnicalData(TechnicalDataType value) {
        this.technicalData = value;
    }

    /**
     * 获取modelGroups属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ModelGroupsType }
     *     
     */
    public ModelGroupsType getModelGroups() {
        return modelGroups;
    }

    /**
     * 设置modelGroups属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ModelGroupsType }
     *     
     */
    public void setModelGroups(ModelGroupsType value) {
        this.modelGroups = value;
    }

}
