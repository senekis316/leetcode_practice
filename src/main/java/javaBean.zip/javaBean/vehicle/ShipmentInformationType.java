
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ShipmentInformationType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ShipmentInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ShipName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ShippingDataList" type="{}ShippingDataListType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentInformationType", propOrder = {
    "shipName",
    "shippingDataList"
})
public class ShipmentInformationType {

    @XmlElement(name = "ShipName", required = true)
    protected String shipName;
    @XmlElement(name = "ShippingDataList", required = true)
    protected ShippingDataListType shippingDataList;

    /**
     * 获取shipName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipName() {
        return shipName;
    }

    /**
     * 设置shipName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipName(String value) {
        this.shipName = value;
    }

    /**
     * 获取shippingDataList属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ShippingDataListType }
     *     
     */
    public ShippingDataListType getShippingDataList() {
        return shippingDataList;
    }

    /**
     * 设置shippingDataList属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ShippingDataListType }
     *     
     */
    public void setShippingDataList(ShippingDataListType value) {
        this.shippingDataList = value;
    }

}
