
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>PRCodingType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="PRCodingType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PRType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PRFamily">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="F_AF"/>
 *               &lt;enumeration value="F_VF"/>
 *               &lt;enumeration value="F_IA"/>
 *               &lt;enumeration value="M_3S1"/>
 *               &lt;enumeration value="M_43C"/>
 *               &lt;enumeration value="M_8IS"/>
 *               &lt;enumeration value="M_8LE"/>
 *               &lt;enumeration value="M_9JB"/>
 *               &lt;enumeration value="M_PN1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="PRNumber">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="2T"/>
 *               &lt;enumeration value="QM"/>
 *               &lt;enumeration value="3S1"/>
 *               &lt;enumeration value="43C"/>
 *               &lt;enumeration value="8IS"/>
 *               &lt;enumeration value="8LE"/>
 *               &lt;enumeration value="9JB"/>
 *               &lt;enumeration value="PN1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Remark">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="黑玉色金属漆"/>
 *               &lt;enumeration value="双色调部分真皮内饰，黑色/莫哈韦米色"/>
 *               &lt;enumeration value="铝合金车顶行李轨"/>
 *               &lt;enumeration value="19 英寸 Cayenne S 车轮"/>
 *               &lt;enumeration value="带保时捷动态照明系统 (PDLS) 的 LED 大灯"/>
 *               &lt;enumeration value="仪表板上的罗盘显示屏, 包含保时捷越野助手应用程序"/>
 *               &lt;enumeration value="吸烟者套装"/>
 *               &lt;enumeration value="豪华组件"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PRCodingType", propOrder = {
    "prType",
    "prFamily",
    "prNumber",
    "remark"
})
public class PRCodingType {

    @XmlElement(name = "PRType", required = true)
    protected String prType;
    @XmlElement(name = "PRFamily", required = true)
    protected String prFamily;
    @XmlElement(name = "PRNumber", required = true)
    protected String prNumber;
    @XmlElement(name = "Remark", required = true)
    protected String remark;

    /**
     * 获取prType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRType() {
        return prType;
    }

    /**
     * 设置prType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRType(String value) {
        this.prType = value;
    }

    /**
     * 获取prFamily属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRFamily() {
        return prFamily;
    }

    /**
     * 设置prFamily属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRFamily(String value) {
        this.prFamily = value;
    }

    /**
     * 获取prNumber属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRNumber() {
        return prNumber;
    }

    /**
     * 设置prNumber属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRNumber(String value) {
        this.prNumber = value;
    }

    /**
     * 获取remark属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 设置remark属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemark(String value) {
        this.remark = value;
    }

}
