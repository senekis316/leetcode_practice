
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ConfirmedDeliveryDateType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ConfirmedDeliveryDateType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FlexibleDateRangeChoice" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Day" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfirmedDeliveryDateType", propOrder = {
    "flexibleDateRangeChoice",
    "day"
})
public class ConfirmedDeliveryDateType {

    @XmlElement(name = "FlexibleDateRangeChoice", required = true)
    protected String flexibleDateRangeChoice;
    @XmlElement(name = "Day", required = true)
    protected String day;

    /**
     * 获取flexibleDateRangeChoice属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlexibleDateRangeChoice() {
        return flexibleDateRangeChoice;
    }

    /**
     * 设置flexibleDateRangeChoice属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlexibleDateRangeChoice(String value) {
        this.flexibleDateRangeChoice = value;
    }

    /**
     * 获取day属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDay() {
        return day;
    }

    /**
     * 设置day属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDay(String value) {
        this.day = value;
    }

}
