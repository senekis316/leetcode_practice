
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>DealerRefType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="DealerRefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DealerIdentifier" type="{}DealerIdentifierType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DealerRefType", propOrder = {
    "dealerIdentifier"
})
public class DealerRefType {

    @XmlElement(name = "DealerIdentifier", required = true)
    protected DealerIdentifierType dealerIdentifier;

    /**
     * 获取dealerIdentifier属性的值。
     * 
     * @return
     *     possible object is
     *     {@link DealerIdentifierType }
     *     
     */
    public DealerIdentifierType getDealerIdentifier() {
        return dealerIdentifier;
    }

    /**
     * 设置dealerIdentifier属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link DealerIdentifierType }
     *     
     */
    public void setDealerIdentifier(DealerIdentifierType value) {
        this.dealerIdentifier = value;
    }

}
