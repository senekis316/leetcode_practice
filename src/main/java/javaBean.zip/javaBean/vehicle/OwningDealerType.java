
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>OwningDealerType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="OwningDealerType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DealerRef" type="{}DealerRefType"/>
 *         &lt;element name="Salesman" type="{}SalesmanType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OwningDealerType", propOrder = {
    "dealerRef",
    "salesman"
})
public class OwningDealerType {

    @XmlElement(name = "DealerRef", required = true)
    protected DealerRefType dealerRef;
    @XmlElement(name = "Salesman", required = true)
    protected SalesmanType salesman;

    /**
     * 获取dealerRef属性的值。
     * 
     * @return
     *     possible object is
     *     {@link DealerRefType }
     *     
     */
    public DealerRefType getDealerRef() {
        return dealerRef;
    }

    /**
     * 设置dealerRef属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link DealerRefType }
     *     
     */
    public void setDealerRef(DealerRefType value) {
        this.dealerRef = value;
    }

    /**
     * 获取salesman属性的值。
     * 
     * @return
     *     possible object is
     *     {@link SalesmanType }
     *     
     */
    public SalesmanType getSalesman() {
        return salesman;
    }

    /**
     * 设置salesman属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link SalesmanType }
     *     
     */
    public void setSalesman(SalesmanType value) {
        this.salesman = value;
    }

}
