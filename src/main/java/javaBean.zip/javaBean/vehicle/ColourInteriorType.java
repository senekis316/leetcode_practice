
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ColourInteriorType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ColourInteriorType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ColourSalesFamilies" type="{}ColourSalesFamiliesType"/>
 *         &lt;element name="InteriorSalesFamilies" type="{}InteriorSalesFamiliesType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ColourInteriorType", propOrder = {
    "colourSalesFamilies",
    "interiorSalesFamilies"
})
public class ColourInteriorType {

    @XmlElement(name = "ColourSalesFamilies", required = true)
    protected ColourSalesFamiliesType colourSalesFamilies;
    @XmlElement(name = "InteriorSalesFamilies", required = true)
    protected InteriorSalesFamiliesType interiorSalesFamilies;

    /**
     * 获取colourSalesFamilies属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ColourSalesFamiliesType }
     *     
     */
    public ColourSalesFamiliesType getColourSalesFamilies() {
        return colourSalesFamilies;
    }

    /**
     * 设置colourSalesFamilies属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ColourSalesFamiliesType }
     *     
     */
    public void setColourSalesFamilies(ColourSalesFamiliesType value) {
        this.colourSalesFamilies = value;
    }

    /**
     * 获取interiorSalesFamilies属性的值。
     * 
     * @return
     *     possible object is
     *     {@link InteriorSalesFamiliesType }
     *     
     */
    public InteriorSalesFamiliesType getInteriorSalesFamilies() {
        return interiorSalesFamilies;
    }

    /**
     * 设置interiorSalesFamilies属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link InteriorSalesFamiliesType }
     *     
     */
    public void setInteriorSalesFamilies(InteriorSalesFamiliesType value) {
        this.interiorSalesFamilies = value;
    }

}
