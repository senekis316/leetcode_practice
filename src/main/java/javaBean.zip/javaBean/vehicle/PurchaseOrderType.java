
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>PurchaseOrderType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="PurchaseOrderType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PurchaseOrderIdentifier" type="{}PurchaseOrderIdentifierType"/>
 *         &lt;element name="OrderStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OrderSubStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TrackingPoints" type="{}TrackingPointsType"/>
 *         &lt;element name="InvolvedParties" type="{}InvolvedPartiesType"/>
 *         &lt;element name="VehicleSpecificationRef" type="{}VehicleSpecificationRefType"/>
 *         &lt;element name="Prices" type="{}PricesType"/>
 *         &lt;element name="ProductionInformation" type="{}ProductionInformationType"/>
 *         &lt;element name="Dates" type="{}DatesType"/>
 *         &lt;element name="DealerInvoice" type="{}DealerInvoiceType"/>
 *         &lt;element name="OrderCategory" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Holds" type="{}HoldsType"/>
 *         &lt;element name="ShipmentInformation" type="{}ShipmentInformationType"/>
 *         &lt;element name="Objectives" type="{}ObjectivesType"/>
 *         &lt;element name="ProcessingInformation" type="{}ProcessingInformationType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PurchaseOrderType", propOrder = {
    "purchaseOrderIdentifier",
    "orderStatus",
    "orderSubStatus",
    "trackingPoints",
    "involvedParties",
    "vehicleSpecificationRef",
    "prices",
    "productionInformation",
    "dates",
    "dealerInvoice",
    "orderCategory",
    "holds",
    "shipmentInformation",
    "objectives",
    "processingInformation"
})
public class PurchaseOrderType {

    @XmlElement(name = "PurchaseOrderIdentifier", required = true)
    protected PurchaseOrderIdentifierType purchaseOrderIdentifier;
    @XmlElement(name = "OrderStatus", required = true)
    protected String orderStatus;
    @XmlElement(name = "OrderSubStatus", required = true)
    protected String orderSubStatus;
    @XmlElement(name = "TrackingPoints", required = true)
    protected TrackingPointsType trackingPoints;
    @XmlElement(name = "InvolvedParties", required = true)
    protected InvolvedPartiesType involvedParties;
    @XmlElement(name = "VehicleSpecificationRef", required = true)
    protected VehicleSpecificationRefType vehicleSpecificationRef;
    @XmlElement(name = "Prices", required = true)
    protected PricesType prices;
    @XmlElement(name = "ProductionInformation", required = true)
    protected ProductionInformationType productionInformation;
    @XmlElement(name = "Dates", required = true)
    protected DatesType dates;
    @XmlElement(name = "DealerInvoice", required = true)
    protected DealerInvoiceType dealerInvoice;
    @XmlElement(name = "OrderCategory", required = true)
    protected String orderCategory;
    @XmlElement(name = "Holds", required = true)
    protected HoldsType holds;
    @XmlElement(name = "ShipmentInformation", required = true)
    protected ShipmentInformationType shipmentInformation;
    @XmlElement(name = "Objectives", required = true)
    protected ObjectivesType objectives;
    @XmlElement(name = "ProcessingInformation", required = true)
    protected ProcessingInformationType processingInformation;

    /**
     * 获取purchaseOrderIdentifier属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PurchaseOrderIdentifierType }
     *     
     */
    public PurchaseOrderIdentifierType getPurchaseOrderIdentifier() {
        return purchaseOrderIdentifier;
    }

    /**
     * 设置purchaseOrderIdentifier属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PurchaseOrderIdentifierType }
     *     
     */
    public void setPurchaseOrderIdentifier(PurchaseOrderIdentifierType value) {
        this.purchaseOrderIdentifier = value;
    }

    /**
     * 获取orderStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderStatus() {
        return orderStatus;
    }

    /**
     * 设置orderStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderStatus(String value) {
        this.orderStatus = value;
    }

    /**
     * 获取orderSubStatus属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderSubStatus() {
        return orderSubStatus;
    }

    /**
     * 设置orderSubStatus属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderSubStatus(String value) {
        this.orderSubStatus = value;
    }

    /**
     * 获取trackingPoints属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrackingPointsType }
     *     
     */
    public TrackingPointsType getTrackingPoints() {
        return trackingPoints;
    }

    /**
     * 设置trackingPoints属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrackingPointsType }
     *     
     */
    public void setTrackingPoints(TrackingPointsType value) {
        this.trackingPoints = value;
    }

    /**
     * 获取involvedParties属性的值。
     * 
     * @return
     *     possible object is
     *     {@link InvolvedPartiesType }
     *     
     */
    public InvolvedPartiesType getInvolvedParties() {
        return involvedParties;
    }

    /**
     * 设置involvedParties属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link InvolvedPartiesType }
     *     
     */
    public void setInvolvedParties(InvolvedPartiesType value) {
        this.involvedParties = value;
    }

    /**
     * 获取vehicleSpecificationRef属性的值。
     * 
     * @return
     *     possible object is
     *     {@link VehicleSpecificationRefType }
     *     
     */
    public VehicleSpecificationRefType getVehicleSpecificationRef() {
        return vehicleSpecificationRef;
    }

    /**
     * 设置vehicleSpecificationRef属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link VehicleSpecificationRefType }
     *     
     */
    public void setVehicleSpecificationRef(VehicleSpecificationRefType value) {
        this.vehicleSpecificationRef = value;
    }

    /**
     * 获取prices属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PricesType }
     *     
     */
    public PricesType getPrices() {
        return prices;
    }

    /**
     * 设置prices属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PricesType }
     *     
     */
    public void setPrices(PricesType value) {
        this.prices = value;
    }

    /**
     * 获取productionInformation属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ProductionInformationType }
     *     
     */
    public ProductionInformationType getProductionInformation() {
        return productionInformation;
    }

    /**
     * 设置productionInformation属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ProductionInformationType }
     *     
     */
    public void setProductionInformation(ProductionInformationType value) {
        this.productionInformation = value;
    }

    /**
     * 获取dates属性的值。
     * 
     * @return
     *     possible object is
     *     {@link DatesType }
     *     
     */
    public DatesType getDates() {
        return dates;
    }

    /**
     * 设置dates属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link DatesType }
     *     
     */
    public void setDates(DatesType value) {
        this.dates = value;
    }

    /**
     * 获取dealerInvoice属性的值。
     * 
     * @return
     *     possible object is
     *     {@link DealerInvoiceType }
     *     
     */
    public DealerInvoiceType getDealerInvoice() {
        return dealerInvoice;
    }

    /**
     * 设置dealerInvoice属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link DealerInvoiceType }
     *     
     */
    public void setDealerInvoice(DealerInvoiceType value) {
        this.dealerInvoice = value;
    }

    /**
     * 获取orderCategory属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderCategory() {
        return orderCategory;
    }

    /**
     * 设置orderCategory属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderCategory(String value) {
        this.orderCategory = value;
    }

    /**
     * 获取holds属性的值。
     * 
     * @return
     *     possible object is
     *     {@link HoldsType }
     *     
     */
    public HoldsType getHolds() {
        return holds;
    }

    /**
     * 设置holds属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link HoldsType }
     *     
     */
    public void setHolds(HoldsType value) {
        this.holds = value;
    }

    /**
     * 获取shipmentInformation属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ShipmentInformationType }
     *     
     */
    public ShipmentInformationType getShipmentInformation() {
        return shipmentInformation;
    }

    /**
     * 设置shipmentInformation属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentInformationType }
     *     
     */
    public void setShipmentInformation(ShipmentInformationType value) {
        this.shipmentInformation = value;
    }

    /**
     * 获取objectives属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ObjectivesType }
     *     
     */
    public ObjectivesType getObjectives() {
        return objectives;
    }

    /**
     * 设置objectives属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectivesType }
     *     
     */
    public void setObjectives(ObjectivesType value) {
        this.objectives = value;
    }

    /**
     * 获取processingInformation属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ProcessingInformationType }
     *     
     */
    public ProcessingInformationType getProcessingInformation() {
        return processingInformation;
    }

    /**
     * 设置processingInformation属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessingInformationType }
     *     
     */
    public void setProcessingInformation(ProcessingInformationType value) {
        this.processingInformation = value;
    }

}
