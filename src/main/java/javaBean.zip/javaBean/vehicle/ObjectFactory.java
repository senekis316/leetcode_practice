
package javaBean.vehicle;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the javaBean package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetOrderResponse_QNAME = new QName("", "GetOrderResponse");
    private final static QName _InteriorSalesFamiliesTypeInteriorSalesFamiliesInterior_QNAME = new QName("", "Interior");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: javaBean
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InteriorSalesFamiliesType }
     * 
     */
    public InteriorSalesFamiliesType createInteriorSalesFamiliesType() {
        return new InteriorSalesFamiliesType();
    }

    /**
     * Create an instance of {@link GetOrderResponseType }
     * 
     */
    public GetOrderResponseType createGetOrderResponseType() {
        return new GetOrderResponseType();
    }

    /**
     * Create an instance of {@link HoldReasonType }
     * 
     */
    public HoldReasonType createHoldReasonType() {
        return new HoldReasonType();
    }

    /**
     * Create an instance of {@link TrackingPointNumberType }
     * 
     */
    public TrackingPointNumberType createTrackingPointNumberType() {
        return new TrackingPointNumberType();
    }

    /**
     * Create an instance of {@link ProcessingInformationType }
     * 
     */
    public ProcessingInformationType createProcessingInformationType() {
        return new ProcessingInformationType();
    }

    /**
     * Create an instance of {@link AttributesListType }
     * 
     */
    public AttributesListType createAttributesListType() {
        return new AttributesListType();
    }

    /**
     * Create an instance of {@link SalesPersonIdentifierType }
     * 
     */
    public SalesPersonIdentifierType createSalesPersonIdentifierType() {
        return new SalesPersonIdentifierType();
    }

    /**
     * Create an instance of {@link VehicleSpecificationIdentifierType }
     * 
     */
    public VehicleSpecificationIdentifierType createVehicleSpecificationIdentifierType() {
        return new VehicleSpecificationIdentifierType();
    }

    /**
     * Create an instance of {@link PurchaseOrderType }
     * 
     */
    public PurchaseOrderType createPurchaseOrderType() {
        return new PurchaseOrderType();
    }

    /**
     * Create an instance of {@link CommissionType }
     * 
     */
    public CommissionType createCommissionType() {
        return new CommissionType();
    }

    /**
     * Create an instance of {@link VehicleSpecificationType }
     * 
     */
    public VehicleSpecificationType createVehicleSpecificationType() {
        return new VehicleSpecificationType();
    }

    /**
     * Create an instance of {@link AttributeType }
     * 
     */
    public AttributeType createAttributeType() {
        return new AttributeType();
    }

    /**
     * Create an instance of {@link DatesType }
     * 
     */
    public DatesType createDatesType() {
        return new DatesType();
    }

    /**
     * Create an instance of {@link ShippingDataType }
     * 
     */
    public ShippingDataType createShippingDataType() {
        return new ShippingDataType();
    }

    /**
     * Create an instance of {@link ObjectiveRefType }
     * 
     */
    public ObjectiveRefType createObjectiveRefType() {
        return new ObjectiveRefType();
    }

    /**
     * Create an instance of {@link ObjectivePeriodType }
     * 
     */
    public ObjectivePeriodType createObjectivePeriodType() {
        return new ObjectivePeriodType();
    }

    /**
     * Create an instance of {@link ModelGroupsType }
     * 
     */
    public ModelGroupsType createModelGroupsType() {
        return new ModelGroupsType();
    }

    /**
     * Create an instance of {@link PicturedDescriptionType }
     * 
     */
    public PicturedDescriptionType createPicturedDescriptionType() {
        return new PicturedDescriptionType();
    }

    /**
     * Create an instance of {@link ShipmentInformationType }
     * 
     */
    public ShipmentInformationType createShipmentInformationType() {
        return new ShipmentInformationType();
    }

    /**
     * Create an instance of {@link InvolvedPartiesType }
     * 
     */
    public InvolvedPartiesType createInvolvedPartiesType() {
        return new InvolvedPartiesType();
    }

    /**
     * Create an instance of {@link AmountType }
     * 
     */
    public AmountType createAmountType() {
        return new AmountType();
    }

    /**
     * Create an instance of {@link TrackingPointsType }
     * 
     */
    public TrackingPointsType createTrackingPointsType() {
        return new TrackingPointsType();
    }

    /**
     * Create an instance of {@link AttributesType }
     * 
     */
    public AttributesType createAttributesType() {
        return new AttributesType();
    }

    /**
     * Create an instance of {@link VehicleSpecificationRefType }
     * 
     */
    public VehicleSpecificationRefType createVehicleSpecificationRefType() {
        return new VehicleSpecificationRefType();
    }

    /**
     * Create an instance of {@link DealerInvoiceType }
     * 
     */
    public DealerInvoiceType createDealerInvoiceType() {
        return new DealerInvoiceType();
    }

    /**
     * Create an instance of {@link PriceType }
     * 
     */
    public PriceType createPriceType() {
        return new PriceType();
    }

    /**
     * Create an instance of {@link TypeType }
     * 
     */
    public TypeType createTypeType() {
        return new TypeType();
    }

    /**
     * Create an instance of {@link FeatureType }
     * 
     */
    public FeatureType createFeatureType() {
        return new FeatureType();
    }

    /**
     * Create an instance of {@link SalesPersonRefType }
     * 
     */
    public SalesPersonRefType createSalesPersonRefType() {
        return new SalesPersonRefType();
    }

    /**
     * Create an instance of {@link ObjectivesType }
     * 
     */
    public ObjectivesType createObjectivesType() {
        return new ObjectivesType();
    }

    /**
     * Create an instance of {@link TopType }
     * 
     */
    public TopType createTopType() {
        return new TopType();
    }

    /**
     * Create an instance of {@link HoldReasonsType }
     * 
     */
    public HoldReasonsType createHoldReasonsType() {
        return new HoldReasonsType();
    }

    /**
     * Create an instance of {@link PurchaseOrderIdentifierType }
     * 
     */
    public PurchaseOrderIdentifierType createPurchaseOrderIdentifierType() {
        return new PurchaseOrderIdentifierType();
    }

    /**
     * Create an instance of {@link DeliveredToDealerType }
     * 
     */
    public DeliveredToDealerType createDeliveredToDealerType() {
        return new DeliveredToDealerType();
    }

    /**
     * Create an instance of {@link ProductionNumberType }
     * 
     */
    public ProductionNumberType createProductionNumberType() {
        return new ProductionNumberType();
    }

    /**
     * Create an instance of {@link ConfirmedDeliveryDateType }
     * 
     */
    public ConfirmedDeliveryDateType createConfirmedDeliveryDateType() {
        return new ConfirmedDeliveryDateType();
    }

    /**
     * Create an instance of {@link PartnerKeyType }
     * 
     */
    public PartnerKeyType createPartnerKeyType() {
        return new PartnerKeyType();
    }

    /**
     * Create an instance of {@link FeaturesType }
     * 
     */
    public FeaturesType createFeaturesType() {
        return new FeaturesType();
    }

    /**
     * Create an instance of {@link DealerRefType }
     * 
     */
    public DealerRefType createDealerRefType() {
        return new DealerRefType();
    }

    /**
     * Create an instance of {@link PricesType }
     * 
     */
    public PricesType createPricesType() {
        return new PricesType();
    }

    /**
     * Create an instance of {@link ColourSalesFamiliesType }
     * 
     */
    public ColourSalesFamiliesType createColourSalesFamiliesType() {
        return new ColourSalesFamiliesType();
    }

    /**
     * Create an instance of {@link TechnicalDataType }
     * 
     */
    public TechnicalDataType createTechnicalDataType() {
        return new TechnicalDataType();
    }

    /**
     * Create an instance of {@link DealerIdentifierType }
     * 
     */
    public DealerIdentifierType createDealerIdentifierType() {
        return new DealerIdentifierType();
    }

    /**
     * Create an instance of {@link InteriorType }
     * 
     */
    public InteriorType createInteriorType() {
        return new InteriorType();
    }

    /**
     * Create an instance of {@link TrackingPointType }
     * 
     */
    public TrackingPointType createTrackingPointType() {
        return new TrackingPointType();
    }

    /**
     * Create an instance of {@link HoldsType }
     * 
     */
    public HoldsType createHoldsType() {
        return new HoldsType();
    }

    /**
     * Create an instance of {@link SalesmanType }
     * 
     */
    public SalesmanType createSalesmanType() {
        return new SalesmanType();
    }

    /**
     * Create an instance of {@link OwningDealerType }
     * 
     */
    public OwningDealerType createOwningDealerType() {
        return new OwningDealerType();
    }

    /**
     * Create an instance of {@link ColourInteriorType }
     * 
     */
    public ColourInteriorType createColourInteriorType() {
        return new ColourInteriorType();
    }

    /**
     * Create an instance of {@link ObjectiveType }
     * 
     */
    public ObjectiveType createObjectiveType() {
        return new ObjectiveType();
    }

    /**
     * Create an instance of {@link PRCodingType }
     * 
     */
    public PRCodingType createPRCodingType() {
        return new PRCodingType();
    }

    /**
     * Create an instance of {@link ProductionInformationType }
     * 
     */
    public ProductionInformationType createProductionInformationType() {
        return new ProductionInformationType();
    }

    /**
     * Create an instance of {@link ShippingDataListType }
     * 
     */
    public ShippingDataListType createShippingDataListType() {
        return new ShippingDataListType();
    }

    /**
     * Create an instance of {@link FinishType }
     * 
     */
    public FinishType createFinishType() {
        return new FinishType();
    }

    /**
     * Create an instance of {@link DescriptionsType }
     * 
     */
    public DescriptionsType createDescriptionsType() {
        return new DescriptionsType();
    }

    /**
     * Create an instance of {@link InteriorSalesFamiliesType.InteriorSalesFamilies }
     * 
     */
    public InteriorSalesFamiliesType.InteriorSalesFamilies createInteriorSalesFamiliesTypeInteriorSalesFamilies() {
        return new InteriorSalesFamiliesType.InteriorSalesFamilies();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetOrderResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "GetOrderResponse")
    public JAXBElement<GetOrderResponseType> createGetOrderResponse(GetOrderResponseType value) {
        return new JAXBElement<GetOrderResponseType>(_GetOrderResponse_QNAME, GetOrderResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InteriorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Interior", scope = InteriorSalesFamiliesType.InteriorSalesFamilies.class)
    public JAXBElement<InteriorType> createInteriorSalesFamiliesTypeInteriorSalesFamiliesInterior(InteriorType value) {
        return new JAXBElement<InteriorType>(_InteriorSalesFamiliesTypeInteriorSalesFamiliesInterior_QNAME, InteriorType.class, InteriorSalesFamiliesType.InteriorSalesFamilies.class, value);
    }

}
