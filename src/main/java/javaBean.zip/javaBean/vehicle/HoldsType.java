
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>HoldsType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="HoldsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HoldTypeIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="HoldReasons" type="{}HoldReasonsType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HoldsType", propOrder = {
    "holdTypeIndicator",
    "holdReasons"
})
public class HoldsType {

    @XmlElement(name = "HoldTypeIndicator", required = true)
    protected String holdTypeIndicator;
    @XmlElement(name = "HoldReasons", required = true)
    protected HoldReasonsType holdReasons;

    /**
     * 获取holdTypeIndicator属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldTypeIndicator() {
        return holdTypeIndicator;
    }

    /**
     * 设置holdTypeIndicator属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldTypeIndicator(String value) {
        this.holdTypeIndicator = value;
    }

    /**
     * 获取holdReasons属性的值。
     * 
     * @return
     *     possible object is
     *     {@link HoldReasonsType }
     *     
     */
    public HoldReasonsType getHoldReasons() {
        return holdReasons;
    }

    /**
     * 设置holdReasons属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link HoldReasonsType }
     *     
     */
    public void setHoldReasons(HoldReasonsType value) {
        this.holdReasons = value;
    }

}
