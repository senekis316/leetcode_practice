
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>SalesPersonRefType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="SalesPersonRefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SalesPersonIdentifier" type="{}SalesPersonIdentifierType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SalesPersonRefType", propOrder = {
    "salesPersonIdentifier"
})
public class SalesPersonRefType {

    @XmlElement(name = "SalesPersonIdentifier", required = true)
    protected SalesPersonIdentifierType salesPersonIdentifier;

    /**
     * 获取salesPersonIdentifier属性的值。
     * 
     * @return
     *     possible object is
     *     {@link SalesPersonIdentifierType }
     *     
     */
    public SalesPersonIdentifierType getSalesPersonIdentifier() {
        return salesPersonIdentifier;
    }

    /**
     * 设置salesPersonIdentifier属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link SalesPersonIdentifierType }
     *     
     */
    public void setSalesPersonIdentifier(SalesPersonIdentifierType value) {
        this.salesPersonIdentifier = value;
    }

}
