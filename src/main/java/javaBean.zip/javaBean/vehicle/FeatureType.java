
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>FeatureType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="FeatureType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PRCoding" type="{}PRCodingType"/>
 *         &lt;element name="Prices" type="{}PricesType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FeatureType", propOrder = {
    "prCoding",
    "prices"
})
public class FeatureType {

    @XmlElement(name = "PRCoding", required = true)
    protected PRCodingType prCoding;
    @XmlElement(name = "Prices")
    protected PricesType prices;

    /**
     * 获取prCoding属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PRCodingType }
     *     
     */
    public PRCodingType getPRCoding() {
        return prCoding;
    }

    /**
     * 设置prCoding属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PRCodingType }
     *     
     */
    public void setPRCoding(PRCodingType value) {
        this.prCoding = value;
    }

    /**
     * 获取prices属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PricesType }
     *     
     */
    public PricesType getPrices() {
        return prices;
    }

    /**
     * 设置prices属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PricesType }
     *     
     */
    public void setPrices(PricesType value) {
        this.prices = value;
    }

}
