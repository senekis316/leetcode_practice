
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>InvolvedPartiesType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="InvolvedPartiesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OwningDealer" type="{}OwningDealerType"/>
 *         &lt;element name="DeliveredToDealer" type="{}DeliveredToDealerType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InvolvedPartiesType", propOrder = {
    "owningDealer",
    "deliveredToDealer"
})
public class InvolvedPartiesType {

    @XmlElement(name = "OwningDealer", required = true)
    protected OwningDealerType owningDealer;
    @XmlElement(name = "DeliveredToDealer", required = true)
    protected DeliveredToDealerType deliveredToDealer;

    /**
     * 获取owningDealer属性的值。
     * 
     * @return
     *     possible object is
     *     {@link OwningDealerType }
     *     
     */
    public OwningDealerType getOwningDealer() {
        return owningDealer;
    }

    /**
     * 设置owningDealer属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link OwningDealerType }
     *     
     */
    public void setOwningDealer(OwningDealerType value) {
        this.owningDealer = value;
    }

    /**
     * 获取deliveredToDealer属性的值。
     * 
     * @return
     *     possible object is
     *     {@link DeliveredToDealerType }
     *     
     */
    public DeliveredToDealerType getDeliveredToDealer() {
        return deliveredToDealer;
    }

    /**
     * 设置deliveredToDealer属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveredToDealerType }
     *     
     */
    public void setDeliveredToDealer(DeliveredToDealerType value) {
        this.deliveredToDealer = value;
    }

}
