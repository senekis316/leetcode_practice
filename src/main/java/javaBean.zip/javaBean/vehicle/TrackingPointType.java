
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>TrackingPointType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="TrackingPointType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TrackingPointNumber" type="{}TrackingPointNumberType"/>
 *         &lt;element name="ReachedDate" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="2019-02-04"/>
 *               &lt;enumeration value="2019-04-08"/>
 *               &lt;enumeration value="2019-03-13"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CurrentETA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TrackingPointType", propOrder = {
    "trackingPointNumber",
    "reachedDate",
    "currentETA"
})
public class TrackingPointType {

    @XmlElement(name = "TrackingPointNumber", required = true)
    protected TrackingPointNumberType trackingPointNumber;
    @XmlElement(name = "ReachedDate")
    protected String reachedDate;
    @XmlElement(name = "CurrentETA")
    protected String currentETA;

    /**
     * 获取trackingPointNumber属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TrackingPointNumberType }
     *     
     */
    public TrackingPointNumberType getTrackingPointNumber() {
        return trackingPointNumber;
    }

    /**
     * 设置trackingPointNumber属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TrackingPointNumberType }
     *     
     */
    public void setTrackingPointNumber(TrackingPointNumberType value) {
        this.trackingPointNumber = value;
    }

    /**
     * 获取reachedDate属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReachedDate() {
        return reachedDate;
    }

    /**
     * 设置reachedDate属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReachedDate(String value) {
        this.reachedDate = value;
    }

    /**
     * 获取currentETA属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentETA() {
        return currentETA;
    }

    /**
     * 设置currentETA属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentETA(String value) {
        this.currentETA = value;
    }

}
