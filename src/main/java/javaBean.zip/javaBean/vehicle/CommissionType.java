
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>CommissionType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="CommissionType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CommissionNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CommisionNumberYear" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CommissionType", propOrder = {
    "bid",
    "commissionNumber",
    "commisionNumberYear"
})
public class CommissionType {

    @XmlElement(name = "BID", required = true)
    protected String bid;
    @XmlElement(name = "CommissionNumber", required = true)
    protected String commissionNumber;
    @XmlElement(name = "CommisionNumberYear", required = true)
    protected String commisionNumberYear;

    /**
     * 获取bid属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBID() {
        return bid;
    }

    /**
     * 设置bid属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBID(String value) {
        this.bid = value;
    }

    /**
     * 获取commissionNumber属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommissionNumber() {
        return commissionNumber;
    }

    /**
     * 设置commissionNumber属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommissionNumber(String value) {
        this.commissionNumber = value;
    }

    /**
     * 获取commisionNumberYear属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommisionNumberYear() {
        return commisionNumberYear;
    }

    /**
     * 设置commisionNumberYear属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommisionNumberYear(String value) {
        this.commisionNumberYear = value;
    }

}
