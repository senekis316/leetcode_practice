
package javaBean.vehicle;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ColourSalesFamiliesType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ColourSalesFamiliesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Finish" type="{}FinishType" minOccurs="0"/>
 *         &lt;element name="Top" type="{}TopType" minOccurs="0"/>
 *         &lt;element name="ColourSalesFamilies" type="{}ColourSalesFamiliesType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ColourSalesFamiliesType", propOrder = {
    "finish",
    "top",
    "colourSalesFamilies"
})
public class ColourSalesFamiliesType {

    @XmlElement(name = "Finish")
    protected FinishType finish;
    @XmlElement(name = "Top")
    protected TopType top;
    @XmlElement(name = "ColourSalesFamilies")
    protected List<ColourSalesFamiliesType> colourSalesFamilies;

    /**
     * 获取finish属性的值。
     * 
     * @return
     *     possible object is
     *     {@link FinishType }
     *     
     */
    public FinishType getFinish() {
        return finish;
    }

    /**
     * 设置finish属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link FinishType }
     *     
     */
    public void setFinish(FinishType value) {
        this.finish = value;
    }

    /**
     * 获取top属性的值。
     * 
     * @return
     *     possible object is
     *     {@link TopType }
     *     
     */
    public TopType getTop() {
        return top;
    }

    /**
     * 设置top属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link TopType }
     *     
     */
    public void setTop(TopType value) {
        this.top = value;
    }

    /**
     * Gets the value of the colourSalesFamilies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the colourSalesFamilies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getColourSalesFamilies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ColourSalesFamiliesType }
     * 
     * 
     */
    public List<ColourSalesFamiliesType> getColourSalesFamilies() {
        if (colourSalesFamilies == null) {
            colourSalesFamilies = new ArrayList<ColourSalesFamiliesType>();
        }
        return this.colourSalesFamilies;
    }

}
