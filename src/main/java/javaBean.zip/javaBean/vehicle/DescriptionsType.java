
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>DescriptionsType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="DescriptionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PicturedDescription" type="{}PicturedDescriptionType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DescriptionsType", propOrder = {
    "picturedDescription"
})
public class DescriptionsType {

    @XmlElement(name = "PicturedDescription", required = true)
    protected PicturedDescriptionType picturedDescription;

    /**
     * 获取picturedDescription属性的值。
     * 
     * @return
     *     possible object is
     *     {@link PicturedDescriptionType }
     *     
     */
    public PicturedDescriptionType getPicturedDescription() {
        return picturedDescription;
    }

    /**
     * 设置picturedDescription属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link PicturedDescriptionType }
     *     
     */
    public void setPicturedDescription(PicturedDescriptionType value) {
        this.picturedDescription = value;
    }

}
