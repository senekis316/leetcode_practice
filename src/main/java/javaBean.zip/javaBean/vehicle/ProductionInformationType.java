
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ProductionInformationType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ProductionInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IFAOrderType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="IFATimingIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProductionNumber" type="{}ProductionNumberType"/>
 *         &lt;element name="VIN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductionInformationType", propOrder = {
    "ifaOrderType",
    "ifaTimingIndicator",
    "productionNumber",
    "vin"
})
public class ProductionInformationType {

    @XmlElement(name = "IFAOrderType", required = true)
    protected String ifaOrderType;
    @XmlElement(name = "IFATimingIndicator", required = true)
    protected String ifaTimingIndicator;
    @XmlElement(name = "ProductionNumber", required = true)
    protected ProductionNumberType productionNumber;
    @XmlElement(name = "VIN", required = true)
    protected String vin;

    /**
     * 获取ifaOrderType属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIFAOrderType() {
        return ifaOrderType;
    }

    /**
     * 设置ifaOrderType属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIFAOrderType(String value) {
        this.ifaOrderType = value;
    }

    /**
     * 获取ifaTimingIndicator属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIFATimingIndicator() {
        return ifaTimingIndicator;
    }

    /**
     * 设置ifaTimingIndicator属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIFATimingIndicator(String value) {
        this.ifaTimingIndicator = value;
    }

    /**
     * 获取productionNumber属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ProductionNumberType }
     *     
     */
    public ProductionNumberType getProductionNumber() {
        return productionNumber;
    }

    /**
     * 设置productionNumber属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ProductionNumberType }
     *     
     */
    public void setProductionNumber(ProductionNumberType value) {
        this.productionNumber = value;
    }

    /**
     * 获取vin属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIN() {
        return vin;
    }

    /**
     * 设置vin属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIN(String value) {
        this.vin = value;
    }

}
