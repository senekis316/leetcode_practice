
package javaBean.vehicle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>TechnicalDataType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="TechnicalDataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AttributesList" type="{}AttributesListType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TechnicalDataType", propOrder = {
    "attributesList"
})
public class TechnicalDataType {

    @XmlElement(name = "AttributesList", required = true)
    protected AttributesListType attributesList;

    /**
     * 获取attributesList属性的值。
     * 
     * @return
     *     possible object is
     *     {@link AttributesListType }
     *     
     */
    public AttributesListType getAttributesList() {
        return attributesList;
    }

    /**
     * 设置attributesList属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link AttributesListType }
     *     
     */
    public void setAttributesList(AttributesListType value) {
        this.attributesList = value;
    }

}
